CUSTOMERS = {
    'fraude':{
        'c4_deny_list_categories':['BIOMETRIC','HEALTH','TRADE','POLITICS','RACE','FAITH','SEX','CRIME'],
        'c4_regex_list_categories':['EMAIL'],
    }
}