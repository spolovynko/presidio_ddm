LANG_MAP = {
    'en':'eng',
    'fr':'fra',
    'nl':'nld'
}

ANALYZER ={
    'from_config_file':True,
    'from_code':False
}

CONF_LEVEL_MAP = {
    'c3':True,
    'c4':False
}

ANONYMIZER = {
    'yes':True,
    'no':False
}

